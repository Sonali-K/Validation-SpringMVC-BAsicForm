package com.cdac.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.beans.Student;
import com.cdac.services.IStudentService;
import com.cdac.services.StudentServiceImpl;
import com.cdac.validator.StudentValidator;

@Controller
public class StudentController {

	@Autowired
	private IStudentService studentService;

	@Autowired
	private StudentValidator studentValidator;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(studentValidator);
	}

	@RequestMapping("/studentform")    
	public String showform(Model m){    
		m.addAttribute("student", new Student());  
		return "studentform";   
	}  


	@RequestMapping(value="/save",method = RequestMethod.POST)    
	public String save(@ModelAttribute("student")@Validated Student student, BindingResult result){
		if (result.hasErrors()) {
			return "studentform";
		} else {
			studentService.save(student);    
			return "redirect:/viewstud";
		}
	}    

	@RequestMapping("/viewstud")    
	public String viewStud(Model m){
		List<Student> list=studentService.getStudents();
		m.addAttribute("list",list);  
		return "viewstud";    
	}


	@RequestMapping(value="/studentedit/{id}")    
	public String edit(@PathVariable int id, Model m){    
		Student student=studentService.getStudentById(id);    
		m.addAttribute("command",student);  
		return "studentedit";    
	}    

	@RequestMapping(value="/editsave",method = RequestMethod.POST)    
	public String editsave(@ModelAttribute("student") Student student){
		studentService.update(student);    
		return "redirect:/viewstud";    
	}    

	@RequestMapping(value="/deletestud/{id}",method = RequestMethod.GET)    
	public String delete(@PathVariable int id){    
		studentService.delete(id);    
		return "redirect:/viewstud";    
	}
}
